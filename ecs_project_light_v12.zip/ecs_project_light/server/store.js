// store.js
// Postgres-backed user + activity store (Neon). Replaces the old flat-file
// (users.json) store, which lost all data on every server restart/redeploy
// because free hosting (Render, etc.) uses an ephemeral filesystem.
//
// Design: each user/activity row keeps its "extra" fields in a JSONB
// column, so the flexible, ever-growing set of user fields used across
// index.js (isPro, plan, stripeCustomerId, bestScore, pendingPlan, ...)
// doesn't require a schema migration every time a new field is added.
import pg from 'pg'

const { Pool } = pg

if (!process.env.DATABASE_URL) {
  console.warn('⚠️  DATABASE_URL is not set. The server will crash on first DB query.')
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
})

let schemaReady = null
function ensureSchema() {
  if (!schemaReady) {
    schemaReady = pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        email TEXT NOT NULL,
        data JSONB NOT NULL DEFAULT '{}'::jsonb,
        created_at TIMESTAMPTZ NOT NULL DEFAULT now()
      );
      CREATE UNIQUE INDEX IF NOT EXISTS users_email_lower_idx ON users ((lower(email)));

      CREATE TABLE IF NOT EXISTS activity (
        id TEXT PRIMARY KEY,
        user_id TEXT,
        data JSONB NOT NULL DEFAULT '{}'::jsonb,
        created_at TIMESTAMPTZ NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS activity_user_id_idx ON activity (user_id);
      CREATE INDEX IF NOT EXISTS activity_created_at_idx ON activity (created_at DESC);
    `)
  }
  return schemaReady
}

function rowToUser(row) {
  if (!row) return null
  return { id: row.id, email: row.email, createdAt: row.data.createdAt || row.created_at, ...row.data }
}

export async function findByEmail(email) {
  await ensureSchema()
  const { rows } = await pool.query('SELECT * FROM users WHERE lower(email) = lower($1) LIMIT 1', [String(email).trim()])
  return rowToUser(rows[0])
}

export async function findById(id) {
  await ensureSchema()
  const { rows } = await pool.query('SELECT * FROM users WHERE id = $1 LIMIT 1', [id])
  return rowToUser(rows[0])
}

export async function listAll() {
  await ensureSchema()
  const { rows } = await pool.query('SELECT * FROM users ORDER BY created_at ASC')
  return rows.map(rowToUser)
}

export async function createUser(user) {
  await ensureSchema()
  const { id, email, ...rest } = user
  await pool.query('INSERT INTO users (id, email, data) VALUES ($1, $2, $3)', [id, email, JSON.stringify(rest)])
  return { id, email, ...rest }
}

export async function updateUser(id, patch) {
  await ensureSchema()
  const existing = await findById(id)
  if (!existing) return null
  const { id: _id, email: existingEmail, ...restExisting } = existing
  const merged = { ...restExisting, ...patch }
  const newEmail = patch.email !== undefined ? patch.email : existingEmail
  delete merged.email
  await pool.query('UPDATE users SET email = $2, data = $3 WHERE id = $1', [id, newEmail, JSON.stringify(merged)])
  return { id, email: newEmail, ...merged }
}

export function toSafeUser(user) {
  if (!user) return null
  const { password, ...safe } = user
  return safe
}

// ---------- Activity log (for the live admin dashboard) ----------
export async function logActivity({ userId, type, page, meta }) {
  await ensureSchema()
  const id = `evt_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`
  const at = new Date().toISOString()
  await pool.query('INSERT INTO activity (id, user_id, data) VALUES ($1, $2, $3)', [
    id, userId, JSON.stringify({ type, page: page || null, meta: meta || null, at }),
  ])
  return { id, userId, type, page: page || null, meta: meta || null, at }
}

export async function getRecentActivity(limit = 50) {
  await ensureSchema()
  const { rows } = await pool.query('SELECT * FROM activity ORDER BY created_at DESC LIMIT $1', [limit])
  return rows.map((r) => ({ id: r.id, userId: r.user_id, ...r.data }))
}

export async function getUserActivity(userId, limit = 100) {
  await ensureSchema()
  const { rows } = await pool.query('SELECT * FROM activity WHERE user_id = $1 ORDER BY created_at DESC LIMIT $2', [userId, limit])
  return rows.map((r) => ({ id: r.id, userId: r.user_id, ...r.data }))
}
