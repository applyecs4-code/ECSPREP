// App.jsx
import React from 'react'
import { BrowserRouter, Routes, Route, useLocation, Navigate } from 'react-router-dom'
import Layout from './components/Layout'
import AdminLayout from './components/AdminLayout'
import AppShell from './components/AppShell'

// Public Pages
import HomePage from './pages/HomePage'
import CoursesPage from './pages/CoursesPage'
import CourseDetailPage from './pages/CourseDetailPage'
import MyCoursesPage from './pages/MyCoursesPage'
import MockTestsPage from './pages/MockTestsPage'
import HseTopicPracticeHub from './pages/HseTopicPracticeHub'
import TopicTestPage from './pages/TopicTestPage'
import CardsPage from './pages/CardsPage'
import PricingPage from './pages/PricingPage'
import BlogPage from './pages/BlogPage'
import BlogPostPage from './pages/BlogPostPage'
import StudyGuidePage from './pages/StudyGuidePage'
import ChapterDetailPage from './pages/ChapterDetailPage'
import GuestTestPage from './pages/GuestTestPage'
import PracticePage from './pages/PracticePage'
import GreenCardMockTest from './pages/GreenCardMockTest'
import SkilledWorkerTest from './pages/SkilledWorkerTest'
import SupervisorTest from './pages/SupervisorTest'
import BlackCardMockTest from './pages/BlackCardMockTest'
import BookPage from './pages/BookPage'
import ECSCardBookingPage from './pages/ECSCardBookingPage'
import PricingPlansPage from './pages/PricingPlansPage'
import LeaderboardPage from './pages/LeaderboardPage'
import CertificatePage from './pages/CertificatePage'
import TermsPage from './pages/TermsPage'
import PrivacyPage from './pages/PrivacyPage'
import NotFoundPage from './pages/NotFoundPage'
import SafetySignsPage from './pages/SafetySignsPage'
import StudyMaterialPage from './pages/StudyMaterialPage'
import VideoLibraryPage from './pages/VideoLibraryPage'
import CommunityPage from './pages/CommunityPage'
import ECSCardInfoPage from './pages/ECSCardInfoPage'

// User Dashboard Pages
import ECSDashboard from './pages/ECSDashboard'
import StudyPlanPage from './pages/StudyPlanPage'
import AIQuizGeneratorPage from './pages/AIQuizGeneratorPage'
import AffiliatePage from './pages/AffiliatePage'
import AnalyticsPage from './pages/AnalyticsPage'
import MyLibraryPage from './pages/MyLibraryPage'
import MyMistakesPage from './pages/MyMistakesPage'
import QuickReviewPage from './pages/QuickReviewPage'
import FlashcardsPage from './pages/FlashcardsPage'
import WrongQuestionsPage from './pages/WrongQuestionsPage'
import AchievementsPage from './pages/AchievementsPage'
import SettingsPage from './pages/SettingsPage'
import SignOutPage from './pages/SignOutPage'
import CheckoutPage from './pages/CheckoutPage'

// Auth Pages
import RegisterPage from './pages/admin/RegisterPage'
import LoginPage from './pages/admin/LoginPage'
import ForgotPasswordPage from './pages/ForgotPasswordPage'
import ResetPasswordPage from './pages/ResetPasswordPage'

// Admin Pages
import AdminDashboard from './pages/admin/AdminDashboard'
import AdminUsers from './pages/admin/AdminUsers'
import AdminUserDetail from './pages/admin/AdminUserDetail'
import AdminTests from './pages/admin/AdminTests'
import AdminQuestions from './pages/admin/AdminQuestions'
import AdminBlog from './pages/admin/AdminBlog'
import AdminAnalytics from './pages/admin/AdminAnalytics'
import AdminSettings from './pages/admin/AdminSettings'
import AdminPaymentRequests from './pages/admin/AdminPaymentRequests'
import AdminCourses from './pages/admin/AdminCourses'

import Header from './components/Header'
import Footer from './components/Footer'
import MobileBottomNav from './components/MobileBottomNav'
import ProtectedRoute from './components/ProtectedRoute'
import AIAssistant from './components/AIAssistant'
import GenericMockTest from './components/GenericMockTest'
import PageTranslator from './components/PageTranslator'
import XPToast from './components/XPToast'
import { extraTests } from './data/extraTests'

// Routes that render their own sidebar shell (AppShell) instead of the
// public marketing Header/Footer — the signed-in "app" area.
const APP_SHELL_PREFIXES = [
  '/dashboard', '/my-mistakes', '/my-library', '/quick-review', '/analytics', '/affiliate',
  '/flashcards', '/revision', '/achievements', '/ai-quiz-generator',
]

function SiteChrome() {
  const location = useLocation()
  const isAppShell = APP_SHELL_PREFIXES.some((p) => location.pathname.startsWith(p))
  if (isAppShell) return null
  return (
    <>
      <Header />
      <MobileBottomNav />
    </>
  )
}

function SiteFooter() {
  const location = useLocation()
  const isAppShell = APP_SHELL_PREFIXES.some((p) => location.pathname.startsWith(p))
  if (isAppShell) return null
  return <Footer />
}

function App() {
  return (
    <BrowserRouter>
      <PageTranslator />
      <SiteChrome />
      <Routes>
        {/* Public + User Routes */}
        <Route element={<Layout />}>
          <Route path="/" element={<HomePage />} />
          <Route path="courses" element={<CoursesPage />} />
          <Route path="courses/:courseId" element={<CourseDetailPage />} />
          <Route path="my-courses" element={<ProtectedRoute><MyCoursesPage /></ProtectedRoute>} />
          <Route path="mock-test" element={<MockTestsPage />} />
          <Route path="ecs-hse-practice" element={<HseTopicPracticeHub />} />
          <Route path="practice" element={<PracticePage />} />
          <Route path="guest-test" element={<GuestTestPage />} />
          <Route path="ecs-green-card-mock-test" element={<GreenCardMockTest />} />
          <Route path="ecs-skilled-worker-test" element={<SkilledWorkerTest />} />
          <Route path="ecs-supervisor-test" element={<SupervisorTest />} />
          <Route path="ecs-black-card-mock-test" element={<BlackCardMockTest />} />
          {Object.keys(extraTests).map((path) => (
            <Route key={path} path={path.replace(/^\//, '')} element={<GenericMockTest />} />
          ))}
          <Route path="topic/:slug" element={<TopicTestPage />} />
          <Route path="study-guide" element={<ProtectedRoute requirePro><StudyGuidePage /></ProtectedRoute>} />
          <Route path="study-guide/:chapterId" element={<ProtectedRoute requirePro><ChapterDetailPage /></ProtectedRoute>} />
          <Route path="quick-review" element={<ProtectedRoute><AppShell><QuickReviewPage /></AppShell></ProtectedRoute>} />
          <Route path="flashcards" element={<ProtectedRoute><AppShell><FlashcardsPage /></AppShell></ProtectedRoute>} />
          <Route path="revision/wrong-questions" element={<ProtectedRoute><AppShell><WrongQuestionsPage /></AppShell></ProtectedRoute>} />
          <Route path="achievements" element={<ProtectedRoute><AppShell><AchievementsPage /></AppShell></ProtectedRoute>} />
          <Route path="my-mistakes" element={<ProtectedRoute><AppShell><MyMistakesPage /></AppShell></ProtectedRoute>} />
          <Route path="my-library" element={<ProtectedRoute><AppShell><MyLibraryPage /></AppShell></ProtectedRoute>} />
          <Route path="analytics" element={<ProtectedRoute><AppShell><AnalyticsPage /></AppShell></ProtectedRoute>} />
          <Route path="dashboard" element={<ProtectedRoute><ECSDashboard /></ProtectedRoute>} />
          <Route path="study-plan" element={<ProtectedRoute><AppShell><StudyPlanPage /></AppShell></ProtectedRoute>} />
          <Route path="ai-quiz-generator" element={<ProtectedRoute requirePro><AIQuizGeneratorPage /></ProtectedRoute>} />
          <Route path="affiliate" element={<ProtectedRoute><AppShell><AffiliatePage /></AppShell></ProtectedRoute>} />
          <Route path="refer" element={<Navigate to="/affiliate" replace />} />
          <Route path="pricing" element={<PricingPage />} />
          <Route path="plans" element={<PricingPlansPage />} />
          <Route path="checkout" element={<CheckoutPage />} />
          <Route path="leaderboard" element={<LeaderboardPage />} />
          <Route path="certificate" element={<ProtectedRoute requirePro><CertificatePage /></ProtectedRoute>} />
          <Route path="book" element={<BookPage />} />
          <Route path="ecscardbooking" element={<ECSCardBookingPage />} />
          <Route path="cards" element={<CardsPage />} />
          <Route path="types-of-ecs-cards" element={<CardsPage />} />
          <Route path="ecs-card-info" element={<ECSCardInfoPage />} />
          <Route path="blog" element={<BlogPage />} />
          <Route path="blog/:slug" element={<BlogPostPage />} />
          <Route path="safety-signs" element={<SafetySignsPage />} />
          <Route path="study-material" element={<StudyMaterialPage />} />
          <Route path="videos" element={<VideoLibraryPage />} />
          <Route path="community" element={<CommunityPage />} />
          <Route path="settings" element={<ProtectedRoute><SettingsPage /></ProtectedRoute>} />
          <Route path="terms" element={<TermsPage />} />
          <Route path="privacy" element={<PrivacyPage />} />
          <Route path="signout" element={<SignOutPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/forgot-password" element={<ForgotPasswordPage />} />
          <Route path="/reset-password" element={<ResetPasswordPage />} />
        </Route>

        {/* Admin Routes */}
        <Route path="/admin" element={<ProtectedRoute requireAdmin><AdminLayout /></ProtectedRoute>}>
          <Route index element={<AdminDashboard />} />
          <Route path="dashboard" element={<AdminDashboard />} />
          <Route path="users" element={<AdminUsers />} />
          <Route path="users/:id" element={<AdminUserDetail />} />
          <Route path="tests" element={<AdminTests />} />
          <Route path="questions" element={<AdminQuestions />} />
          <Route path="blog" element={<AdminBlog />} />
          <Route path="analytics" element={<AdminAnalytics />} />
          <Route path="settings" element={<AdminSettings />} />
          <Route path="payment-requests" element={<AdminPaymentRequests />} />
          <Route path="courses" element={<AdminCourses />} />
        </Route>

        <Route path="*" element={<NotFoundPage />} />
      </Routes>
      <SiteFooter />
      <AIAssistant />
      <XPToast />
    </BrowserRouter>
  )
}

export default App
