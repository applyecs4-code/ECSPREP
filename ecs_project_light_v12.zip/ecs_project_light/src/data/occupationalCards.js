// data/occupationalCards.js
// The 13 cards on the main Cards page cover the core colour/level system.
// This file covers the wider set of *occupational* ECS card routes —
// specific job titles within that system (e.g. "Installation Electrician",
// "FESS Technician"). Each one is mapped to whichever real mock test on
// this site best matches its occupation, so every card links to a working
// practice test instead of a dead end.

export const occupationalCategories = [
  { id: 'entry', name: 'Entry & General Routes', icon: '🚪', desc: 'Starting points on site before you specialise into a trade.' },
  { id: 'electrical', name: 'Electrical Trades', icon: '⚡', desc: 'Installation, maintenance and specialist electrical occupations.' },
  { id: 'fess', name: 'Fire, Emergency & Security Systems (FESS)', icon: '🔥', desc: 'Fire alarm, emergency lighting and security system installers and engineers.' },
  { id: 'network', name: 'Network & Telecoms', icon: '📡', desc: 'Structured cabling, telecoms and mobile network infrastructure roles.' },
  { id: 'av', name: 'AV, Broadcast & Creative Production', icon: '🎤', desc: 'Audio-visual, broadcast and live event technical roles.' },
  { id: 'management', name: 'Site Management', icon: '📊', desc: 'Supervisory and management routes for running sites and contracts.' },
  { id: 'other', name: 'Other Specialist Routes', icon: '📄', desc: 'Vehicle, lighting and other specialist installer occupations.' },
]

export const occupationalCards = [
  // Entry & general
  { name: 'Labourer', category: 'entry', desc: 'Entry-level route for general site support and basic labouring duties.', path: '/ecs-green-card-mock-test' },
  { name: 'Electrical Labourer', category: 'entry', desc: 'For workers assisting qualified electricians on electrical sites.', path: '/ecs-green-card-mock-test' },
  { name: 'Apprentice', category: 'entry', desc: 'For anyone on a recognised electrical apprenticeship framework.', path: '/ecs-green-card-mock-test' },
  { name: 'Trainee Electrician', category: 'electrical', desc: 'For trainees working towards a full electrician qualification.', path: '/ecs-hse-assessment' },
  { name: 'Industry Placement (T-Level)', category: 'entry', desc: 'For T-Level students completing a supervised industry placement.', path: '/ecs-green-card-mock-test' },
  { name: 'Experienced Worker (Gold Stripe – Temp)', category: 'entry', desc: 'Temporary route for experienced workers progressing towards a full card.', path: '/ecs-skilled-worker-test' },
  { name: 'Site Support Occupations', category: 'entry', desc: 'For non-electrical site roles that still need ECS recognition.', path: '/ecs-green-card-mock-test' },

  // Electrical trades
  { name: 'Provisional Installation Electrician', category: 'electrical', desc: 'Provisional card while final evidence for the full installation route is completed.', path: '/ecs-hse-assessment' },
  { name: 'Installation Electrician (Gold)', category: 'electrical', desc: 'Skilled-worker gold card for fully qualified installation electricians.', path: '/ecs-hse-assessment' },
  { name: 'Approved Electrician (Gold)', category: 'electrical', desc: 'Gold card for electricians assessed to Approved Electrician level.', path: '/ecs-hse-assessment' },
  { name: 'Registered Electrician (Gold)', category: 'electrical', desc: 'Gold card confirming Registered Electrician status against current standards.', path: '/ecs-hse-assessment' },
  { name: 'Technician (Gold)', category: 'electrical', desc: 'Advanced technical-level card for experienced technicians and specialists.', path: '/ecs-hse-assessment' },
  { name: 'Maintenance Electrician', category: 'electrical', desc: 'Gold card for electricians focused on planned and reactive maintenance.', path: '/ecs-hse-assessment' },
  { name: 'Electrical Fitter', category: 'electrical', desc: 'Gold card route for electrical fitting and panel-based installation work.', path: '/ecs-hse-assessment' },
  { name: 'Engineering Maintenance Electrician', category: 'electrical', desc: 'Gold card for engineering-focused electrical maintenance roles.', path: '/ecs-hse-assessment' },
  { name: 'Wireman & Panel Builder', category: 'electrical', desc: 'For workers assembling, wiring and testing electrical control panels.', path: '/ecs-hse-assessment' },
  { name: 'Marine Electrician', category: 'electrical', desc: 'Gold card route for electrical work aboard ships and marine installations.', path: '/ecs-hse-assessment' },
  { name: 'Auto Electrician', category: 'electrical', desc: 'For automotive electrical installation and diagnostic work.', path: '/ecs-hse-assessment' },
  { name: 'Electrical Product Service Engineer', category: 'electrical', desc: 'Service and repair specialist for electrical equipment and products.', path: '/ecs-hse-assessment' },
  { name: 'Electrical Winder', category: 'electrical', desc: 'Specialist in winding and refurbishing motors and electrical machines.', path: '/ecs-hse-assessment' },
  { name: 'Distribution Networks Electrician', category: 'electrical', desc: 'Electrician focused on electricity distribution network systems.', path: '/ecs-hse-assessment' },
  { name: 'Instruments Mechanic', category: 'electrical', desc: 'For roles working with instrumentation and control systems.', path: '/ecs-hse-assessment' },

  // FESS
  { name: 'FESS Apprentice', category: 'fess', desc: 'For apprentices training in Fire, Emergency & Security Systems.', path: '/ecs-fess-assessment' },
  { name: 'FESS Labourer', category: 'fess', desc: 'Entry-level labouring card within the FESS occupational structure.', path: '/ecs-fess-assessment' },
  { name: 'FESS Systems Operative', category: 'fess', desc: 'Technical operative card for FESS installation and servicing work.', path: '/ecs-fess-assessment' },
  { name: 'FESS Systems Technician / Engineer', category: 'fess', desc: 'Higher-level FESS card for technicians and engineers.', path: '/ecs-fess-assessment' },
  { name: 'Building Controls Installer / Engineer', category: 'fess', desc: 'For specialists installing building controls and automation systems.', path: '/ecs-fess-assessment' },

  // Network & telecoms
  { name: 'Network Infrastructure Assistant', category: 'network', desc: 'Assistant-level card for network and structured cabling work.', path: '/ecs-network-infrastructure-assessment' },
  { name: 'Network Infrastructure Installer', category: 'network', desc: 'Installer and technician levels for network infrastructure routes.', path: '/ecs-network-infrastructure-assessment' },
  { name: 'LV Jointer', category: 'network', desc: 'Low-voltage jointer working on LV distribution networks.', path: '/ecs-network-infrastructure-assessment' },
  { name: 'Telecommunications Fitter', category: 'network', desc: 'Installer and maintenance card for telecoms fitting work.', path: '/ecs-network-infrastructure-assessment' },
  { name: 'Cellular Network Field Engineer', category: 'network', desc: 'Field engineer card for mobile and cellular network work.', path: '/ecs-network-infrastructure-assessment' },
  { name: 'Signal Distribution Specialist', category: 'network', desc: 'Specialist in distribution of broadcast and signal systems.', path: '/ecs-network-infrastructure-assessment' },
  { name: 'Telecoms Operative', category: 'network', desc: 'Operative-level card for general telecoms field work.', path: '/ecs-network-infrastructure-assessment' },

  // AV / broadcast / creative
  { name: 'AV Operative / AV Technician', category: 'av', desc: 'Audio-visual technician and operative roles across venues and events.', path: '/ecs-hse-assessment' },
  { name: 'Broadcast & Media Supervisor', category: 'av', desc: 'Supervisory card for broadcast and media technical operations.', path: '/ecs-hse-assessment' },
  { name: 'Creative Production Operative', category: 'av', desc: 'Supporting technical work in stage, theatre and live events.', path: '/ecs-hse-assessment' },
  { name: 'Creative Production Technician', category: 'av', desc: 'Technical role supporting creative and live event production.', path: '/ecs-hse-assessment' },
  { name: 'Creative Production Manager', category: 'av', desc: 'Management-level card for leading creative and live event teams.', path: '/ecs-hse-assessment' },
  { name: 'ISCVE AV Engineer', category: 'av', desc: 'AV engineer route recognised through ISCVE membership.', path: '/ecs-hse-assessment' },
  { name: 'ISCVE Sound Engineer', category: 'av', desc: 'Sound engineer card for permanent and installed sound systems.', path: '/ecs-hse-assessment' },
  { name: 'AVIXA Commercial AV Integrator', category: 'av', desc: 'AV integration specialist route recognised via AVIXA pathways.', path: '/ecs-hse-assessment' },
  { name: 'Radio & Television Electrician', category: 'av', desc: 'Electrical and signal work for broadcast and media environments.', path: '/ecs-hse-assessment' },

  // Site management
  { name: 'Site Supervisor', category: 'management', desc: 'Supervisory-level card for overseeing electrotechnical work on site.', path: '/ecs-supervisor-test' },
  { name: 'Site Manager', category: 'management', desc: 'Site management card for leading projects and delivery on site.', path: '/ecs-black-card-mock-test' },
  { name: 'Contracts Manager', category: 'management', desc: 'Senior card route for managing contracts and commercial delivery.', path: '/ecs-black-card-mock-test' },
  { name: 'Project Manager', category: 'management', desc: 'Management-level route for project planning and coordination.', path: '/ecs-black-card-mock-test' },
  { name: 'Academically Qualified Person (AQP)', category: 'management', desc: 'For holders of a suitable academic qualification in a related discipline.', path: '/ecs-black-card-mock-test' },
  { name: 'Professionally Qualified Person (PQP)', category: 'management', desc: 'For members of approved professional institutions and bodies.', path: '/ecs-black-card-mock-test' },

  // Other specialist
  { name: 'Vehicle Installer', category: 'other', desc: 'For workers installing electrical and electronic systems in vehicles.', path: '/ecs-hse-assessment' },
  { name: 'Gate Safe Installer', category: 'other', desc: 'Automatic gate and barrier installation specialist route.', path: '/ecs-hse-assessment' },
  { name: 'SLL Lighting Professional', category: 'other', desc: 'Lighting design and consultancy route recognised by the SLL.', path: '/ecs-hse-assessment' },
]
