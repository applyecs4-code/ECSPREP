// data/extraTests.js
//
// As of 2026, ECS (ecscard.org.uk) runs exactly FOUR assessment types.
// This file is scoped to those four (keyed by route path), plus 11
// topic-focused HSE practice routes (one per official HSE topic) so users
// can drill their weak areas using only official ECS questions.
//
// HSE Assessment: mandatory for every ECS card holder. This is the ONLY one
// of the four for which ECS publishes a full official question bank (their
// Revision Guide) — so info.official === true and the questions come
// from the real 327-question bank, drawn 50 at a time following ECS's own
// topic distribution (see officialEcsHse.js). The 11 topic-practice routes
// also draw exclusively from that same official bank, just filtered to one
// topic — so they're official content too.
//
// FESS / Network Infrastructure / Electrical Safety Unit: ECS does NOT
// publish question banks for these — only topic/assessment guides. The
// question sets here are original practice content and are clearly marked
// official: false, with a disclaimer and a link to the real ECS guidance,
// so users are never misled into thinking they've seen the real exam
// questions.

import {
  hseQuestionBank,
  generateHseExam,
  generateHseTopicPractice,
  getHseTopicQuestionCounts,
  HSE_TOPIC_DISTRIBUTION,
  HSE_EXAM_INFO,
} from './officialEcsHse'
import { fessQuestionBank, FESS_EXAM_INFO } from './officialEcsFess'
import { networkQuestionBank, NETWORK_EXAM_INFO } from './officialEcsNetwork'
import { electricalSafetyQuestionBank, ELECTRICAL_SAFETY_EXAM_INFO } from './officialEcsElectricalSafety'

const TOPIC_ICONS = {
  1: '📋', 2: '📦', 3: '📝', 4: '🦺', 5: '🧼',
  6: '🔥', 7: '🪜', 8: '🛠️', 9: '⚠️', 10: '⚡', 11: '♻️',
}

export const extraTests = {
  '/ecs-hse-assessment': {
    title: 'ECS Health, Safety and Environmental (HSE) Assessment',
    icon: '🦺',
    duration: 30 * 60, // 30 minutes, matching the real assessment
    passMark: 43 / 50, // 43 out of 50, matching the real assessment
    // Fresh 50-question draw each time the test is started, following the
    // official ECS topic distribution, with answer order randomised too —
    // just like the real assessment.
    getQuestions: generateHseExam,
    info: HSE_EXAM_INFO,
    topicDistribution: HSE_TOPIC_DISTRIBUTION,
    totalBankSize: hseQuestionBank.length,
    isFullExam: true,
  },

  '/ecs-fess-assessment': {
    title: 'ECS FESS (Fire, Emergency and Security Systems) Assessment',
    icon: '🔥',
    duration: 30 * 60,
    passMark: 0.8,
    questions: fessQuestionBank,
    info: FESS_EXAM_INFO,
  },

  '/ecs-network-infrastructure-assessment': {
    title: 'ECS Network Infrastructure Assessment',
    icon: '🌐',
    duration: 30 * 60,
    passMark: 0.8,
    questions: networkQuestionBank,
    info: NETWORK_EXAM_INFO,
  },

  '/ecs-electrical-safety-unit-assessment': {
    title: 'ECS Electrical Safety Unit Assessment',
    icon: '⚡',
    duration: 30 * 60,
    passMark: 0.8,
    questions: electricalSafetyQuestionBank,
    info: ELECTRICAL_SAFETY_EXAM_INFO,
  },
}

// 11 topic-focused HSE practice routes — one per official ECS HSE topic.
// Every question is still drawn from the real 327-question official bank,
// just filtered down to a single topic, so these stay official: true.
const topicCounts = getHseTopicQuestionCounts()

export const hseTopicPracticeTests = HSE_TOPIC_DISTRIBUTION.map(({ categoryId, category, questionsInExam }) => {
  const path = `/ecs-hse-practice-${categoryId}`
  const total = topicCounts[categoryId] || 0
  extraTests[path] = {
    title: `HSE Topic Practice: ${category}`,
    icon: TOPIC_ICONS[categoryId] || '📖',
    duration: Math.max(total * 60, 5 * 60), // ~1 min per question, min 5 min
    passMark: 0.8,
    getQuestions: () => generateHseTopicPractice(categoryId),
    info: {
      ...HSE_EXAM_INFO,
      title: `HSE Topic Practice — ${category}`,
      sourceNote: `Official ECS HSE Revision Guide — every question here is one of the ${total} official questions for the "${category}" topic.`,
    },
    categoryId,
    category,
    topicQuestionCount: total,
    questionsInRealExam: questionsInExam,
  }
  return { categoryId, category, path, icon: TOPIC_ICONS[categoryId] || '📖', total, questionsInExam }
})
