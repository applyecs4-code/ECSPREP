// data/blogPosts.js
// Single source of truth for every blog post. Both BlogPage.jsx (listing)
// and BlogPostPage.jsx (detail view) import from here — do not duplicate
// this data anywhere else in the codebase.
//
// Each post includes a focusKeyword (target ~2% density in `content`),
// an SEO-ready metaDescription, and an `faqs` array that feeds the
// FAQPage JSON-LD schema (Seo.jsx -> faqSchema) for Featured Snippets,
// Google AI Overviews, ChatGPT Search, Gemini and Perplexity citations.

export const blogPosts = [
  {
    id: 1,
    title: "How to Pass the ECS Test First Time: Complete 2026 Guide",
    slug: "how-to-pass-ecs-test-first-time",
    date: "June 2, 2026",
    author: "ECSPrep Editorial Team",
    readTime: "9 min read",
    focusKeyword: "pass the ECS test",
    excerpt:
      "A step-by-step revision plan to pass the ECS test first time: how the ECS Health, Safety and Environment exam works, what to study, and the mistakes that cause most first-attempt fails.",
    metaDescription:
      "How to pass the ECS test first time in 2026: exam format, pass mark, a 2-week revision plan, and the most common reasons candidates fail the ECS HS&E test.",
    content: `
<p>Around one in five candidates fails the ECS Health, Safety and Environment (HS&E) test on their first attempt — not because the material is unusually difficult, but because they walk in under-prepared for the exact format of the exam. If your goal is to <strong>pass the ECS test</strong> on your first try, the fastest route is understanding precisely what you're being asked to do, then drilling the topics that carry the most marks.</p>

<h2>What the ECS Test Actually Involves</h2>
<p>The "ECS test" is really the ECS Health, Safety and Environment test, sat on a touchscreen computer at a Pearson VUE or ECS test centre. Whichever version you take — Operatives, Specialists, or Managers and Professionals (MAP) — the format is the same: 50 multiple-choice questions in 45 minutes, with a pass mark of 45 out of 50 (90%). There's no negative marking, so every question should get an answer, even a guess. A small number of questions each require two correct selections, and both must be right to score the mark — there's no partial credit.</p>
<p>Questions are drawn from a bank covering five to six core knowledge areas depending on the version: working environment, occupational health, general safety, high-risk activities, environment, and — for the MAP test — legal and management responsibilities. Recent updates to the syllabus have also added weight to mental health, leadership, and behavioural safety questions, so don't assume the test only covers PPE and signage.</p>

<h2>Why Most First Attempts Fail</h2>
<p>Three patterns show up again and again in candidates who don't pass the ECS test on their first sitting:</p>
<ul>
<li><strong>Relying on site experience instead of the syllabus.</strong> Experienced workers often answer based on what actually happens on their site rather than what the ECS syllabus states is correct. The test rewards the textbook answer, not the practical shortcut.</li>
<li><strong>Skipping timed practice.</strong> Forty-five minutes for fifty questions sounds generous until you hit a scenario-based question you have to re-read twice. Practising untimed builds knowledge but not exam speed.</li>
<li><strong>Ignoring "select two" questions.</strong> These trip people up because you can know one correct answer confidently and still lose the mark by guessing the second.</li>
</ul>

<h2>A Realistic 2-Week Revision Plan</h2>
<p>You don't need months to pass the ECS test — most candidates who prepare properly need one to two weeks of focused practice, at roughly 30 minutes a day.</p>
<ol>
<li><strong>Days 1–3:</strong> Work through each core topic individually rather than jumping straight into a full mock. Identify the two or three sections where your score is weakest.</li>
<li><strong>Days 4–8:</strong> Revisit your weak topics daily, reading the explanation behind every question you get wrong rather than just noting the correct letter.</li>
<li><strong>Days 9–12:</strong> Start taking full 50-question timed mock tests under exam conditions — no notes, no pausing the clock, phone away.</li>
<li><strong>Days 13–14:</strong> Once you're consistently scoring 47+ out of 50 across mixed-topic mocks, book your test. Consistency across multiple mocks matters more than one lucky high score.</li>
</ol>

<h2>On the Day: Practical Tips</h2>
<p>Bring valid photo ID — a UK driving licence or passport is accepted, and you won't be allowed to sit the test without one. Arrive early; the touchscreen system takes a minute to get used to if you've never seen it. If English isn't your first language, an audio version is available in multiple languages for the Operatives test — use it if it helps, there's no penalty. Read every question fully before answering; some questions are worded to test whether you've actually understood the scenario, not just recognised a keyword.</p>

<h2>What Happens If You Don't Pass</h2>
<p>If you don't pass the ECS test, you can rebook and retake it — there's no cap on attempts, though you'll need to leave a short gap and pay the test fee again each time. This is exactly why first-attempt preparation matters: every retake costs both time and money, on top of delaying your ECS card application and, often, your start date on site.</p>

<h2>Frequently Asked Questions</h2>
<h3>How many questions do I need to get right to pass the ECS test?</h3>
<p>You need 45 out of 50 correct (90%) to pass the Operatives or Specialists version. There's no partial credit on "select two" questions — both answers must be correct.</p>
<h3>How long should I revise before taking the ECS test?</h3>
<p>Most candidates who study consistently for 30 minutes a day pass within one to two weeks. The key is timed, mixed-topic mock tests in the final few days, not just reading revision notes.</p>
<h3>Can I retake the ECS test if I fail?</h3>
<p>Yes. There's no limit on retakes, but you'll pay the test fee again each time, so it's worth being genuinely ready before you book rather than treating the first sitting as a practice run.</p>
`,
    faqs: [
      { q: "How many questions do I need to get right to pass the ECS test?", a: "You need 45 out of 50 correct (90%) to pass the Operatives or Specialists version. There's no partial credit on \"select two\" questions — both answers must be correct." },
      { q: "How long should I revise before taking the ECS test?", a: "Most candidates who study consistently for 30 minutes a day pass within one to two weeks. The key is timed, mixed-topic mock tests in the final few days, not just reading revision notes." },
      { q: "Can I retake the ECS test if I fail?", a: "Yes. There's no limit on retakes, but you'll pay the test fee again each time, so it's worth being genuinely ready before you book rather than treating the first sitting as a practice run." },
    ],
  },
  {
    id: 2,
    title: "ECS Test Format 2026: Questions, Timing and Pass Mark Explained",
    slug: "ecs-test-pass-rate-2026",
    date: "May 17, 2026",
    author: "ECSPrep Editorial Team",
    readTime: "6 min read",
    focusKeyword: "ECS test format",
    excerpt:
      "A full breakdown of the ECS test format: how many questions, how long you get, the exact pass mark, and how scoring works on select-two questions.",
    metaDescription:
      "ECS test format 2026 explained: 50 questions, 45 minutes, 90% pass mark, and how select-two questions are scored on the ECS Health, Safety and Environment test.",
    content: `
<p>Before you can revise effectively, you need to understand the <strong>ECS test format</strong> itself — how many questions you'll face, how much time you have, and exactly what score counts as a pass. Getting this wrong is one of the easiest ways to waste revision time on the wrong things.</p>

<h2>Question Count and Timing</h2>
<p>Every version of the ECS Health, Safety and Environment test — Operatives, Specialists, and Managers and Professionals — follows the same core ECS test format: 50 multiple-choice questions to be completed in 45 minutes. That works out to under a minute per question on average, though in practice some questions take seconds and scenario-based ones take longer, so pacing yourself across the full 45 minutes matters more than treating each question identically.</p>

<h2>The Pass Mark</h2>
<p>The pass mark across the ECS test format is 45 out of 50 correct answers — 90%. This is a deliberately high bar: ECS set it there because the test isn't measuring general competence, it's confirming a specific, consistent standard of health and safety awareness before someone is allowed on a construction site. There's no partial pass and no rounding — 44 out of 50 is a fail, however close it feels.</p>

<h2>How Questions Are Structured</h2>
<p>Most questions in the ECS test format are standard multiple-choice: a scenario or factual prompt followed by four answer options (A–D), with one correct answer. A smaller number — typically four to six questions per paper — are "select two" questions, where you must identify both correct answers from the options given. Scoring on these is strict: selecting one correct and one incorrect option scores zero for that question, there's no half-credit.</p>
<p>There's no negative marking anywhere on the test, which means guessing is always better than leaving a question blank. A blank answer is a guaranteed zero; a guess is at least a 25% chance of scoring the mark on a four-option question.</p>

<h2>Question Topics by Test Version</h2>
<p>The Operatives and Specialists tests draw from five core knowledge areas: working environment, occupational health, general safety, high-risk activities, and environment. The Managers and Professionals (MAP) test covers all of that plus additional legal and management-focused material, including CDM regulations. If you're not sure which version applies to you, it depends on the ECS card you're applying for, not your job title alone.</p>

<h2>Frequently Asked Questions</h2>
<h3>How many questions are on the ECS test?</h3>
<p>50 multiple-choice questions, regardless of which version (Operatives, Specialists or Managers and Professionals) you're sitting.</p>
<h3>What is the pass mark for the ECS test?</h3>
<p>45 out of 50 correct answers, which is 90%. This applies consistently across all versions of the test.</p>
<h3>Is there negative marking on the ECS test?</h3>
<p>No. Wrong answers don't lose you marks, so you should always select an answer rather than leaving a question blank.</p>
`,
    faqs: [
      { q: "How many questions are on the ECS test?", a: "50 multiple-choice questions, regardless of which version (Operatives, Specialists or Managers and Professionals) you're sitting." },
      { q: "What is the pass mark for the ECS test?", a: "45 out of 50 correct answers, which is 90%. This applies consistently across all versions of the test." },
      { q: "Is there negative marking on the ECS test?", a: "No. Wrong answers don't lose you marks, so you should always select an answer rather than leaving a question blank." },
    ],
  },
  {
    id: 3,
    title: "How Long Does the ECS Test Take? Timing and Pacing Explained",
    slug: "how-long-does-ecs-test-take",
    date: "May 17, 2026",
    author: "ECSPrep Editorial Team",
    readTime: "5 min read",
    focusKeyword: "how long does the ECS test take",
    excerpt:
      "The ECS test takes 45 minutes for 50 questions — here's how to pace yourself, where candidates lose time, and how to practise under realistic timing conditions.",
    metaDescription:
      "How long does the ECS test take? 45 minutes for 50 questions. A full guide to pacing, time management, and practising under real exam timing.",
    content: `
<p>If you're asking <strong>how long does the ECS test take</strong>, the short answer is 45 minutes for 50 multiple-choice questions — but the more useful answer is how to use that time well, because poor pacing is a common reason candidates run out of time on the final few questions.</p>

<h2>The Official Time Limit</h2>
<p>The ECS Health, Safety and Environment test gives every candidate 45 minutes to answer 50 questions, regardless of which version — Operatives, Specialists or Managers and Professionals — you're taking. That averages to 54 seconds per question, though the real distribution isn't even: simple factual questions ("what colour is a mandatory PPE sign?") take a few seconds, while scenario-based questions describing a situation on site and asking what you should do next take considerably longer to read and reason through.</p>

<h2>Where Candidates Lose Time</h2>
<p>Three habits eat up time unnecessarily during the real test:</p>
<ul>
<li><strong>Re-reading questions multiple times.</strong> This usually happens when a candidate hasn't practised enough scenario-based questions beforehand and is parsing the wording for the first time under pressure.</li>
<li><strong>Second-guessing an initial answer.</strong> Going back to change answers repeatedly burns minutes you'll need later. Trust your first read if you've prepared properly.</li>
<li><strong>Getting stuck on one hard question.</strong> There's no reward for spending five minutes on a single question. Answer with your best guess, flag it if the system allows, and move on — you can return if time permits.</li>
</ul>

<h2>How to Practise Under Realistic Timing</h2>
<p>The single most useful thing you can do to build real confidence is to take full mock tests under a strict 45-minute clock — no pausing, no notes. Practising topic-by-topic without a timer builds knowledge, but it doesn't build the pacing instinct you need on test day. In the final few days before your booking, switch entirely to timed, mixed-topic mocks so the 45-minute rhythm feels familiar rather than stressful.</p>
<p>Note that there's no option to pause the clock in the real exam, even though some practice platforms offer this. Train the way you'll be tested.</p>

<h2>Frequently Asked Questions</h2>
<h3>How long does the ECS test take to complete?</h3>
<p>You're given 45 minutes to answer all 50 questions. Most candidates who are properly prepared finish with time to spare and use the remainder to review flagged answers.</p>
<h3>Can I pause the timer during the real ECS test?</h3>
<p>No. The 45-minute clock runs continuously once the test starts, so practising under strict timed conditions beforehand is important.</p>
<h3>How much time should I spend per question?</h3>
<p>Roughly 54 seconds on average, but treat that as a guide, not a rule — spend less time on factual questions and save the extra minutes for scenario-based ones.</p>
`,
    faqs: [
      { q: "How long does the ECS test take to complete?", a: "You're given 45 minutes to answer all 50 questions. Most candidates who are properly prepared finish with time to spare and use the remainder to review flagged answers." },
      { q: "Can I pause the timer during the real ECS test?", a: "No. The 45-minute clock runs continuously once the test starts, so practising under strict timed conditions beforehand is important." },
      { q: "How much time should I spend per question?", a: "Roughly 54 seconds on average, but treat that as a guide, not a rule — spend less time on factual questions and save the extra minutes for scenario-based ones." },
    ],
  },
  {
    id: 4,
    title: "ECS Test Cost 2026: Fees, Retakes and How to Avoid Paying Twice",
    slug: "ecs-test-cost-2026",
    date: "May 17, 2026",
    author: "ECSPrep Editorial Team",
    readTime: "6 min read",
    focusKeyword: "ECS test cost",
    excerpt:
      "A clear breakdown of the ECS test cost in 2026, what a retake costs, and the revision approach that saves you from paying the fee more than once.",
    metaDescription:
      "ECS test cost 2026: official ECS test fees, retake pricing, and how to avoid paying twice by preparing properly the first time.",
    content: `
<p>Understanding the <strong>ECS test cost</strong> before you book matters, because the fee is charged every time you sit the test — pass or fail. Budgeting for one sitting, done properly, is almost always cheaper than budgeting for two.</p>

<h2>The Official ECS Test Fee</h2>
<p>The ECS Health, Safety and Environment test, sat at a Pearson VUE or ECS-approved test centre, carries a set fee payable directly to ECS or the test centre at the time of booking. This is separate from — and in addition to — any ECS card application fee you'll pay afterwards once you've passed. The exact ECS test cost is periodically reviewed by ECS, so always confirm the current fee on ECS's own booking page before you pay, rather than relying on a figure quoted elsewhere, including this article.</p>

<h2>What a Retake Costs</h2>
<p>If you don't pass, a retake costs the same fee as your first attempt — there's no discount for repeat sittings. Candidates typically need to wait a short period (commonly 48 hours) before rebooking. There's no limit on the number of retakes allowed, but each one adds up: two failed attempts before finally passing effectively means paying that fee three times over, on top of losing time you could have spent preparing better the first time.</p>

<h2>Other Costs to Budget For</h2>
<p>Beyond the test fee itself, factor in:</p>
<ul>
<li><strong>Revision materials.</strong> Official ECS revision books and apps carry their own cost, though free mock test platforms cover the same syllabus at no charge for a sample test.</li>
<li><strong>Travel to a test centre.</strong> Test centres aren't in every town, so factor in travel time and cost, especially if you're booking a retake and want to avoid a repeat journey.</li>
<li><strong>Time off work.</strong> Many candidates underestimate this — a failed test often means a second day off work to retake it.</li>
</ul>

<h2>How to Avoid Paying Twice</h2>
<p>The most reliable way to control your ECS test cost is simple: don't book the real test until you're consistently passing full-length, timed mock tests at 90% or higher across mixed topics — not just on your strongest subject. A single high mock score isn't proof of readiness; consistency across several attempts is.</p>

<h2>Frequently Asked Questions</h2>
<h3>Does the ECS test cost more if I book a Managers and Professionals version?</h3>
<p>Test fees can vary slightly between test versions and are set by ECS, so always check the current fee for your specific test type directly with ECS before booking.</p>
<h3>Do I pay again if I fail and retake the ECS test?</h3>
<p>Yes, the full fee is payable again for every retake. There's no reduced-price retake option.</p>
<h3>Is the ECS card application fee included in the test cost?</h3>
<p>No, the ECS Health, Safety and Environment test fee and the separate ECS card application fee are billed independently.</p>
`,
    faqs: [
      { q: "Does the ECS test cost more if I book a Managers and Professionals version?", a: "Test fees can vary slightly between test versions and are set by ECS, so always check the current fee for your specific test type directly with ECS before booking." },
      { q: "Do I pay again if I fail and retake the ECS test?", a: "Yes, the full fee is payable again for every retake. There's no reduced-price retake option." },
      { q: "Is the ECS card application fee included in the test cost?", a: "No, the ECS Health, Safety and Environment test fee and the separate ECS card application fee are billed independently." },
    ],
  },
  {
    id: 5,
    title: "What Happens If You Fail the ECS Test?",
    slug: "what-happens-if-you-fail-ecs-test",
    date: "May 17, 2026",
    author: "ECSPrep Editorial Team",
    readTime: "6 min read",
    focusKeyword: "fail the ECS test",
    excerpt:
      "What actually happens if you fail the ECS test: how soon you can retake it, what to change in your revision, and how to avoid failing a second time.",
    metaDescription:
      "What happens if you fail the ECS test? How soon you can retake it, what it costs, and how to prepare differently before your next attempt.",
    content: `
<p>If you <strong>fail the ECS test</strong>, it isn't the end of the road — but understanding exactly what happens next helps you avoid failing a second time for the same avoidable reasons.</p>

<h2>You Get Your Result Immediately</h2>
<p>Unlike many exams, you don't wait days for a result. The ECS Health, Safety and Environment test is scored automatically the moment you finish, and you'll see a pass or fail result on screen before you leave the test centre. A printed score report is provided, showing your result and a breakdown by topic area — keep this, as it's genuinely useful for targeting revision if you need to retake.</p>

<h2>What You Can and Can't Do Immediately After</h2>
<p>If you fail the ECS test, you cannot apply for the ECS card you were working towards until you pass. You'll need to rebook and pay the test fee again — there's no reduced-price retake. Most test centres and ECS's own booking system require a short waiting period, commonly 48 hours, before you can sit the test again, so it's not something you can simply repeat the same day.</p>

<h2>Use the Topic Breakdown, Don't Just Repeat Blind Revision</h2>
<p>The single biggest mistake after a failed attempt is revising the same way and hoping for a different result. Your score report shows which knowledge areas you were weakest in — working environment, occupational health, high-risk activities, and so on. Before you rebook:</p>
<ul>
<li>Identify the two or three topics where you lost the most marks, using your score breakdown.</li>
<li>Drill those topics specifically with topic-only practice, not full mixed mocks, until your score in that area improves noticeably.</li>
<li>Only return to full timed mock tests once your weak topics are genuinely stronger, then confirm consistency across several mocks before rebooking.</li>
</ul>

<h2>It's More Common Than You Might Think</h2>
<p>A meaningful proportion of candidates don't pass on their first attempt, often because they underestimated how specific the ECS syllabus answers are compared with everyday site practice, or because they didn't practise under real timed conditions. Failing once doesn't affect future attempts or your ability to reapply — there's no cap on retakes — but repeated failures do cost time, money, and can delay a start date on site, so it's worth treating the second attempt with more structured preparation than the first.</p>

<h2>Frequently Asked Questions</h2>
<h3>How soon can I retake the ECS test after failing?</h3>
<p>Most test centres require a short waiting period, commonly around 48 hours, before you can rebook and sit the test again.</p>
<h3>Do I need to pay again if I fail the ECS test?</h3>
<p>Yes, the full test fee is payable for every attempt, including retakes. There's no discount for a second or third sitting.</p>
<h3>Will failing the ECS test affect my ECS card application?</h3>
<p>You simply cannot apply for the card until you pass. Failing itself isn't recorded against you elsewhere — you can retake as many times as needed.</p>
`,
    faqs: [
      { q: "How soon can I retake the ECS test after failing?", a: "Most test centres require a short waiting period, commonly around 48 hours, before you can rebook and sit the test again." },
      { q: "Do I need to pay again if I fail the ECS test?", a: "Yes, the full test fee is payable for every attempt, including retakes. There's no discount for a second or third sitting." },
      { q: "Will failing the ECS test affect my ECS card application?", a: "You simply cannot apply for the card until you pass. Failing itself isn't recorded against you elsewhere — you can retake as many times as needed." },
    ],
  },
  {
    id: 6,
    title: "ECS Card Types Explained 2026: Colours, Requirements and Which One You Need",
    slug: "ecs-card-types-explained-2026",
    date: "May 17, 2026",
    author: "ECSPrep Editorial Team",
    readTime: "8 min read",
    focusKeyword: "ECS card types",
    excerpt:
      "A full guide to ECS card types by colour — Green, Blue, Gold, Black, White and more — what each one requires, and how to work out which card applies to your role.",
    metaDescription:
      "ECS card types explained 2026: what Green, Blue, Gold, Black and White ECS cards mean, who needs each one, and the ECS test required for each.",
    content: `
<p>Understanding the different <strong>ECS card types</strong> matters before you book your test, because the card colour you need determines which version of the ECS Health, Safety and Environment test you should sit — and turning up having prepared for the wrong one wastes both time and money.</p>

<h2>Why Card Colour Matters</h2>
<p>The various ECS card types exist because construction sites need a fast, visual way to confirm a worker's role and qualification level. Each colour has its own eligibility requirements — typically a combination of an NVQ or equivalent qualification, plus a pass on the relevant ECS HS&E test. The card itself doesn't qualify you to do a job; it's proof that you've met the training and safety-awareness standard the industry requires for that role.</p>

<h2>Green Card — Labourer</h2>
<p>The Green Labourer Card is the most common entry point into construction. It requires passing the Operatives version of the ECS test, plus an approved health and safety awareness course or equivalent. It's aimed at general labourers who don't yet hold an NVQ in a specific trade.</p>

<h2>Blue Card — Skilled Worker</h2>
<p>The Blue Skilled Worker card requires an NVQ Level 2 (or equivalent) in a specific construction trade, plus a pass on the Operatives HS&E test. This is the standard card for qualified tradespeople — electricians, bricklayers, carpenters and similar roles — once they've completed formal trade training.</p>

<h2>Gold Card — Advanced Craft or Supervisor</h2>
<p>Gold cards cover two distinct groups: Advanced Craft workers with an NVQ Level 3 in their trade, and Supervisors who hold a relevant supervisory NVQ. Supervisors typically need to pass the Specialists or Supervisor-level HS&E test rather than the standard Operatives version, reflecting the broader responsibility of the role.</p>

<h2>Black Card — Manager</h2>
<p>The Black Manager card requires a construction-related NVQ at Level 6 or above, or a current SMSTS (Site Management Safety Training Scheme) certificate, combined with a pass on the Managers and Professionals (MAP) version of the HS&E test — the most comprehensive version, covering legal and CDM knowledge in addition to the core safety syllabus.</p>

<h2>White Card — Academically or Professionally Qualified</h2>
<p>White cards are for two related groups: Academically Qualified Persons (holding a relevant construction degree without industry NVQ experience yet) and Professionally Qualified Persons (holding recognised professional body membership). Both also require a pass on the MAP test.</p>

<h2>How to Work Out Which Card You Need</h2>
<p>Working out which of the ECS card types applies to you depends on your current qualifications and the role you'll be doing on site — not simply your job title. If you're unsure, checking against your specific NVQ level and role responsibilities is the reliable way to confirm it, since applying for the wrong card type, or revising for the wrong version of the test, means starting the process again.</p>

<h2>Frequently Asked Questions</h2>
<h3>What's the difference between a Green and Blue ECS card?</h3>
<p>The Green Labourer card doesn't require a trade NVQ, while the Blue Skilled Worker card requires an NVQ Level 2 in a specific trade. Both require passing the Operatives HS&E test.</p>
<h3>Do all ECS card types require the same test?</h3>
<p>No. Most cards require the Operatives test, but Supervisor-level Gold cards and the Black and White cards require higher-level versions (Specialists or Managers and Professionals) that cover additional material.</p>
<h3>Can I upgrade my ECS card type later?</h3>
<p>Yes, as you gain higher qualifications — for example completing an NVQ Level 3 — you can apply for a higher card type, though this generally means sitting the corresponding higher-level HS&E test.</p>
`,
    faqs: [
      { q: "What's the difference between a Green and Blue ECS card?", a: "The Green Labourer card doesn't require a trade NVQ, while the Blue Skilled Worker card requires an NVQ Level 2 in a specific trade. Both require passing the Operatives HS&E test." },
      { q: "Do all ECS card types require the same test?", a: "No. Most cards require the Operatives test, but Supervisor-level Gold cards and the Black and White cards require higher-level versions (Specialists or Managers and Professionals) that cover additional material." },
      { q: "Can I upgrade my ECS card type later?", a: "Yes, as you gain higher qualifications — for example completing an NVQ Level 3 — you can apply for a higher card type, though this generally means sitting the corresponding higher-level HS&E test." },
    ],
  },
]

export function getPostBySlug(slug) {
  return blogPosts.find((p) => p.slug === slug)
}
