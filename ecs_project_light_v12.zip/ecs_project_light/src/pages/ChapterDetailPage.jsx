// pages/ChapterDetailPage.jsx
import React from 'react'
import { useParams, Link } from 'react-router-dom'

function ChapterDetailPage() {
  const { chapterId } = useParams()
  
  const chapters = {
    1: { title: "Accidental Reporting and Recording", content: "Full content here..." },
    2: { title: "Electrical Safety and Tools", content: "Full content here..." },
    // ... add all chapters
  }
  
  const chapter = chapters[chapterId]
  
  if (!chapter) {
    return <div>Chapter not found</div>
  }
  
  return (
    <div style={{ maxWidth: '800px', margin: '0 auto' }}>
      <Link to="/study-guide" style={{ color: '#f59e0b', textDecoration: 'none', display: 'inline-block', marginBottom: '20px' }}>
        ← Back to Study Guide
      </Link>
      <h1>{chapter.title}</h1>
      <div style={{ background: 'white', padding: '30px', borderRadius: '10px', marginTop: '20px' }}>
        <p>{chapter.content}</p>
      </div>
    </div>
  )
}

export default ChapterDetailPage