// pages/ECSCardBookingPage.jsx — independent "Book your ECS Card" enquiry form.
// On submit: the applicant's details are emailed to the team first, then the
// browser redirects to the PayPal payment link to complete payment.
import React, { useState, useEffect } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import {
  CreditCard, User, Mail, Phone, Calendar, Briefcase, MapPin,
  CheckCircle2, Send, MessageCircle, ShieldCheck, Clock, AlertCircle,
} from 'lucide-react'
import { apiRequest } from '../lib/api'
import Seo from '../components/Seo'

// Update this to your real WhatsApp business number (with country code, no + or spaces)
const WHATSAPP_NUMBER = '447000000000'

// PayPal payment link the applicant is sent to once their booking details are submitted
const PAYPAL_LINK = 'https://www.paypal.com/ncp/payment/EFUEBGBW2G86N'
const REDIRECT_DELAY_MS = 3000

const CARD_TYPES = [
  'Trainee',
  'Apprentice',
  'Labourer (Green Card)',
  'Skilled Worker',
  'Advanced Craft / Skilled Worker',
  'Experienced Worker',
  'Supervisor (Gold Card)',
  'Manager (Black Card)',
  'Experienced Technical/Supervisor/Manager',
  'Academically Qualified Person',
  'Professionally Qualified Person',
  'Industry Placement',
  'Provisional',
  'Not sure — please advise me',
]

const initialForm = {
  fullName: '',
  dob: '',
  email: '',
  phone: '',
  address: '',
  employer: '',
  cardType: CARD_TYPES[0],
  hasPassedTest: 'yes',
  preferredDate: '',
  notes: '',
}

function ECSCardBookingPage() {
  const [searchParams] = useSearchParams()
  const typeFromUrl = searchParams.get('type') || ''
  const cardOptions = typeFromUrl && !CARD_TYPES.includes(typeFromUrl)
    ? [typeFromUrl, ...CARD_TYPES]
    : CARD_TYPES

  const [form, setForm] = useState({ ...initialForm, cardType: typeFromUrl || CARD_TYPES[0] })
  const [errors, setErrors] = useState({})
  const [submitting, setSubmitting] = useState(false)
  const [submitError, setSubmitError] = useState('')
  const [done, setDone] = useState(false)

  const update = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }))

  const validate = () => {
    const errs = {}
    if (!form.fullName.trim()) errs.fullName = 'Full name is required.'
    if (!form.dob) errs.dob = 'Date of birth is required.'
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) errs.email = 'Enter a valid email address.'
    if (!/^[0-9+()\s-]{7,}$/.test(form.phone)) errs.phone = 'Enter a valid phone number.'
    if (!form.address.trim()) errs.address = 'Address is required.'
    setErrors(errs)
    return Object.keys(errs).length === 0
  }

  const whatsappMessage = encodeURIComponent(
    `Hi, I'd like to book my ECS card.\nName: ${form.fullName}\nCard type: ${form.cardType}\nPhone: ${form.phone}`
  )
  const whatsappLink = `https://wa.me/${WHATSAPP_NUMBER}?text=${whatsappMessage}`

  const [secondsLeft, setSecondsLeft] = useState(REDIRECT_DELAY_MS / 1000)

  useEffect(() => {
    if (!done) return
    if (secondsLeft <= 0) {
      window.location.href = PAYPAL_LINK
      return
    }
    const t = setTimeout(() => setSecondsLeft((s) => s - 1), 1000)
    return () => clearTimeout(t)
  }, [done, secondsLeft])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSubmitError('')
    if (!validate()) return
    setSubmitting(true)
    try {
      // 1. Send the applicant's details to the team by email
      await apiRequest('/api/book-card', {
        method: 'POST',
        auth: false,
        body: form,
      })
      // 2. Then move to the confirmation screen, which auto-redirects to PayPal
      setDone(true)
    } catch (err) {
      setSubmitError(err.message || 'Something went wrong. Please try again or message us on WhatsApp.')
    } finally {
      setSubmitting(false)
    }
  }

  if (done) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center">
        <div className="w-16 h-16 rounded-full bg-blue-50 flex items-center justify-center mx-auto mb-5">
          <CheckCircle2 className="text-blue-600" size={32} />
        </div>
        <h1 className="text-2xl font-bold text-slate-900 mb-2">Details received!</h1>
        <p className="text-slate-500 mb-8">
          Thanks {form.fullName.split(' ')[0] || ''}, we've sent your ECS card booking details to our team.
          You're being redirected to the secure PayPal payment page to complete your booking
          in <span className="font-semibold text-blue-600">{secondsLeft}s</span>...
        </p>
        <a
          href={PAYPAL_LINK}
          className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-semibold transition"
        >
          <CreditCard size={18} /> Proceed to Payment Now
        </a>
        <div className="mt-4">
          <a
            href={whatsappLink}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 text-green-700 hover:underline text-sm font-medium"
          >
            <MessageCircle size={16} /> Or message us on WhatsApp instead
          </a>
        </div>
        <div className="mt-6">
          <Link to="/" className="text-slate-400 hover:underline text-sm">← Back to home</Link>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-10">
      <Seo title="Book Your ECS Card" description="Submit your details to book your ECS card — no payment taken online, our team follows up to confirm." />

      <div className="text-center mb-8">
        <div className="w-14 h-14 rounded-2xl bg-blue-50 flex items-center justify-center mx-auto mb-4">
          <CreditCard className="text-blue-600" size={28} />
        </div>
        <h1 className="text-3xl font-bold text-slate-900">Book Your ECS Card</h1>
        <p className="text-slate-500 mt-2 max-w-xl mx-auto">
          Fill in your details below. Once submitted, we'll email your booking details to our
          team and take you to a secure PayPal page to complete payment.
        </p>
      </div>

      <div className="bg-blue-50 border border-blue-200 text-blue-800 rounded-xl px-4 py-3 text-sm flex items-start gap-2 mb-8">
        <AlertCircle size={18} className="mt-0.5 shrink-0" />
        <span>
          Please don't attach ID documents (passport, driving licence, etc.) in this form.
          Once we contact you, we'll share a secure way to verify your identity.
        </span>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 md:p-8 space-y-6">
        <div className="grid md:grid-cols-2 gap-5">
          <Field label="Full name" icon={User} error={errors.fullName}>
            <input value={form.fullName} onChange={update('fullName')} type="text" placeholder="John Smith"
              className={inputClass(errors.fullName)} />
          </Field>

          <Field label="Date of birth" icon={Calendar} error={errors.dob}>
            <input value={form.dob} onChange={update('dob')} type="date" className={inputClass(errors.dob)} />
          </Field>

          <Field label="Email address" icon={Mail} error={errors.email}>
            <input value={form.email} onChange={update('email')} type="email" placeholder="you@example.com"
              className={inputClass(errors.email)} />
          </Field>

          <Field label="Phone number" icon={Phone} error={errors.phone}>
            <input value={form.phone} onChange={update('phone')} type="tel" placeholder="07123 456789"
              className={inputClass(errors.phone)} />
          </Field>

          <Field label="Employer / company (optional)" icon={Briefcase}>
            <input value={form.employer} onChange={update('employer')} type="text" placeholder="e.g. ABC Construction Ltd"
              className={inputClass()} />
          </Field>

          <Field label="Preferred contact date (optional)" icon={Clock}>
            <input value={form.preferredDate} onChange={update('preferredDate')} type="date" className={inputClass()} />
          </Field>
        </div>

        <Field label="Home address" icon={MapPin} error={errors.address}>
          <input value={form.address} onChange={update('address')} type="text" placeholder="Street, city, postcode"
            className={inputClass(errors.address)} />
        </Field>

        <div className="grid md:grid-cols-2 gap-5">
          <Field label="Which ECS card do you need?" icon={ShieldCheck}>
            <select value={form.cardType} onChange={update('cardType')} className={inputClass()}>
              {cardOptions.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </Field>

          <Field label="Have you passed the HS&E test?" icon={CheckCircle2}>
            <select value={form.hasPassedTest} onChange={update('hasPassedTest')} className={inputClass()}>
              <option value="yes">Yes, I've already passed</option>
              <option value="no">Not yet</option>
              <option value="unsure">Not sure</option>
            </select>
          </Field>
        </div>

        <Field label="Anything else we should know? (optional)">
          <textarea value={form.notes} onChange={update('notes')} rows={3} placeholder="Any additional info..."
            className={inputClass() + ' resize-none'} />
        </Field>

        {submitError && (
          <div className="bg-rose-50 border border-rose-200 text-rose-700 rounded-lg px-4 py-3 text-sm">
            {submitError}
          </div>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white py-3.5 rounded-xl font-semibold transition"
        >
          <Send size={18} /> {submitting ? 'Submitting...' : 'Submit Booking Request'}
        </button>

        <p className="text-xs text-slate-400 text-center">
          By submitting, you agree to be contacted about your ECS card booking. You'll be
          redirected to PayPal on a secure paypal.com page to complete your payment.
        </p>
      </form>
    </div>
  )
}

function inputClass(error) {
  return `w-full px-4 py-2.5 rounded-lg border ${error ? 'border-rose-400' : 'border-slate-200'} focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-800 placeholder:text-slate-400 bg-slate-50 focus:bg-white transition`
}

function Field({ label, icon: Icon, error, children }) {
  return (
    <label className="block">
      <span className="flex items-center gap-1.5 text-sm font-medium text-slate-700 mb-1.5">
        {Icon && <Icon size={14} className="text-slate-400" />} {label}
      </span>
      {children}
      {error && <span className="text-xs text-rose-500 mt-1 block">{error}</span>}
    </label>
  )
}

export default ECSCardBookingPage
